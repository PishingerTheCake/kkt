# game-for-education-2
Založ projekt v IDEE a naklonuj kód.
Projekt březen 2024
